#pragma once

#include "Component.h"

namespace JFF
{
	class $safeitemname$ : public Component
	{
	public:
		// Ctor & Dtor
		$safeitemname$(GameObject* const gameObject, const char* name, bool initiallyEnabled);
		virtual ~$safeitemname$();

		// Copy ctor and copy assignment
		$safeitemname$(const $safeitemname$& other) = delete;
		$safeitemname$& operator=(const $safeitemname$& other) = delete;

		// Move ctor and assignment
		$safeitemname$($safeitemname$&& other) = delete;
		$safeitemname$ operator=($safeitemname$&& other) = delete;

		// ------------------------------- COMPONENT OVERRIDES ------------------------------- //

		virtual void onStart() override;
		//virtual void onEnable() override;
		//virtual void onUpdate() override;
		//virtual void onDisable() noexcept override;
		//virtual void onDestroy() noexcept override;

		// ------------------------------- $safeitemname$ OVERRIDES ------------------------------- //

		// TODO: add your functions here

	protected:
		// TODO: add your member variables and types here
	};
}