#include "$safeitemname$.h"

#include "Log.h"

JFF::$safeitemname$::$safeitemname$(GameObject* const gameObject, const char* name, bool initiallyEnabled) :
	Component(gameObject, name, initiallyEnabled)
{
	JFF_LOG_INFO("Ctor $safeitemname$")
}

JFF::$safeitemname$::~$safeitemname$()
{
	JFF_LOG_INFO("Dtor $safeitemname$")
}

void JFF::$safeitemname$::onStart()
{
	// TODO: Enter your starting code here
}
