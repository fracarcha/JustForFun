#include "$safeitemname$.h"

std::shared_ptr<JFF::Interface> JFF::Interface::create()
{
	return std::make_shared<JFF::$safeitemname$>();
}

JFF::$safeitemname$::$safeitemname$() : 
	// Default base ctor is automatically called here
	value(false),
	value2(0),
	value3(0LL)
{}

JFF::$safeitemname$::$safeitemname$(unsigned long long a) :
	// BaseClassCtor(a), // Call here non default base class ctor
	value(false),
	value2(0),
	value3(a)
{}

JFF::$safeitemname$::~$safeitemname$()
{} // At the end of scope, ~BaseClassDtor() is called

JFF::$safeitemname$::$safeitemname$(const JFF::$safeitemname$& original) :
	// BaseClassCtor(original) // Call here base's copy constructor
	value(original.value),
	value2(original.value2),
	value3(original.value3)
{}

void JFF::$safeitemname$::f1(int a, float b) const
{
	// TODO: Implement f1()
}

bool JFF::$safeitemname$::f2() const
{
	// TODO: Implement f2()
	return false;
}

int JFF::$safeitemname$::f4() const noexcept(true)
{
	// TODO: Implement f4()
	return 0;
}

const JFF::$safeitemname$ JFF::$safeitemname$::operator+(const $safeitemname$& b) const
{
	return $safeitemname$(value3 + b.value3);
}

const JFF::$safeitemname$ JFF::$safeitemname$::operator<<(const $safeitemname$& b) const
{
	// TODO: Implement operator<<()
	return $safeitemname$();
}

template<typename T>
inline JFF::$safeitemname$& JFF::$safeitemname$::operator=(const T& other)
{
	// TODO: insert return statement here
}

JFF::$safeitemname$& JFF::$safeitemname$::operator*=(const $safeitemname$& other)
{
	value2 *= other.value2;
	return *this;
}

template<typename T>
JFF::$safeitemname$& JFF::$safeitemname$::operator*=(const T& other)
{
	// TODO: insert return statement here
}

JFF::$safeitemname$& JFF::$safeitemname$::operator++()
{
	++value2;
	return *this;
}

const JFF::$safeitemname$ JFF::$safeitemname$::operator++(int)
{
	$safeitemname$ tmp(*this);
	value2++;
	return tmp;
}

inline void JFF::$safeitemname$::f6() const
{
	// TODO: Implement
}

template<> // Template specialization
const bool JFF::$safeitemname$::operator==<JFF::$safeitemname$>(const JFF::$safeitemname$& other)
{
	return value == other.value && value2 == other.value2 && value3 == other.value3;
}

template<typename T>
const bool JFF::$safeitemname$::operator==(const T& other)
{
	return false; // If T is not $safeitemname$, return false. Otherwise, template specialization above will be used
}

template<> // Template specialization
const bool JFF::$safeitemname$::operator< <JFF::$safeitemname$>(const JFF::$safeitemname$& other) // Careful with < (less than) symbol here
{
	return value2 < other.value2;
}

template<typename T>
const bool JFF::$safeitemname$::operator<(const T& other)
{
	return value2 < other;
}

template<typename T, typename Idx>
T& JFF::$safeitemname$::operator[](Idx i)
{
	// TODO: insert return statement here
}

template<typename T>
T& JFF::$safeitemname$::operator*()
{
	// TODO: insert return statement here
}

template<typename T>
T* JFF::$safeitemname$::operator&()
{
	return nullptr;
}
