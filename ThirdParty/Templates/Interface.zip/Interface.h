#pragma once
#include <memory>

namespace JFF
{
	class $safeitemname$
	{
	public:
		// Single implementation factory. This is useful when only one third party library is chosen and the others are macro-hidden
		static std::shared_ptr<$safeitemname$> create();

		// Virtual destructor to avoid memory leak when using polymorphism
		virtual ~$safeitemname$() {}

		// Some functions
		virtual void f1(int a, float b = 0.f) const = 0;
		virtual bool f2() const = 0;
	};
}