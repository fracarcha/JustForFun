#pragma once
#include "Interface.h"

namespace JFF
{
	class $safeitemname$ : public Interface
	{
	public: // TODO: Delete unused functions
		// Ctors
		explicit $safeitemname$();
		explicit $safeitemname$(unsigned long long a);

		// Virtual destructor to avoid memory leak when using polymorphism
		virtual ~$safeitemname$();

		// Copy ctor and assignment
		$safeitemname$(const $safeitemname$& original);
		$safeitemname$& operator=(const $safeitemname$& original) = delete;

		// Move ctor and assignment
		explicit $safeitemname$($safeitemname$&& original) = delete;
		$safeitemname$ operator=($safeitemname$&& original) = delete;

		// Implementation of interface functions
		virtual void f1(int a, float b = 0.f) const override;
		virtual bool f2() const override;

		// New overrideable functions
		//virtual const void* const f3() const = 0; // This would make the whole class abstract
		virtual int f4() const noexcept(true); // Declared to not throw any exception

		// Inside class operators
		// ====================================
		// Arithmetic operators
		const $safeitemname$ operator+(const $safeitemname$& b) const;
		const $safeitemname$ operator<<(const $safeitemname$& b) const;

		// Assignment operators
		template<typename T> $safeitemname$& operator=(const T& other); // Other object assignment
		$safeitemname$& operator*=(const $safeitemname$& other);
		template<typename T> $safeitemname$& operator*=(const T& other);

		// Increment operators
		$safeitemname$& operator++(); // ++a (lvalue)
		const $safeitemname$ operator++(int); // a++ (int parameter used to differentiate from ++a operator) (prvalue)

		// Comparator operators
		template<typename T> const bool operator==(const T& other);
		template<typename T> const bool operator<(const T& other);

		// Access operators
		template<typename T, typename Idx> T& operator[](Idx i); // Array style access
		template<typename T> T& operator*(); // Dereference operator
		template<typename T> T* operator&(); // Adress-of operator

		// Function operator
		template<typename Result, typename Arg1, typename Arg2> Result operator()(const Arg1& a, Arg2& b, ...); // Function object operator

	protected:
		bool value;
		mutable int value2; // This class member can be modified even in const member functions
		unsigned long long value3;

	private:
		// Non overrideable functions
		const bool& f5(bool a = false) const { return value; } // Inline function (just for being defined in class declaration)
		bool& f5(bool a = false) { return const_cast<bool&>(static_cast<const $safeitemname$&>(*this).f5(a)); } // Non const version of f5()
		inline void f6() const; // Potentially inline function
		const decltype(value) f7() const { return value; }
		template<typename T> const T f8(const T& a, const T& b) const { return a + b; }
	};

	// Outside class operators
	// =================================
	// Arithmetic operators
	const $safeitemname$ operator+(const $safeitemname$& a, const $safeitemname$& b) { return a.operator+(b); }
	const $safeitemname$ operator<<(const $safeitemname$& a, const $safeitemname$& b) { return $safeitemname$(a.operator<<(b)); }

	// Assignment operators
	$safeitemname$& operator*=($safeitemname$& a, const $safeitemname$& b) { return a.operator*=(b); }
	template<typename T, typename U> T& operator*=(T& a, const U& b) { return a.operator*=(b); }

	// Increment operators
	$safeitemname$& operator++($safeitemname$& a) { return a.operator++(); } // ++a (lvalue)
	const $safeitemname$ operator++($safeitemname$& a, int) { return $safeitemname$(a.operator++(0)); } // a++ (int parameter used to differentiate from ++a operator) (prvalue)

	// Comparator operators
	template<typename T, typename U> bool operator==(const T& a, const U& b) { return a.operator==(b); }
	template<typename T, typename U> bool operator<(const T& a, const U& b) { return a.operator<(b); }
	
	// Literal operators (Cannot be inside a class)
	const $safeitemname$ operator ""_MySuffix(unsigned long long a) { return $safeitemname$(a); } // Example: Literal 1.2_MySuffix is converted to $fileinputname$

	
}